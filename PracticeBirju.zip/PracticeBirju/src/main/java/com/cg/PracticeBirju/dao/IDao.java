package com.cg.PracticeBirju.dao;

import java.util.List;

import com.cg.PracticeBirju.bean.User;

public interface IDao {

	User addNewUser(User user);

	List<User> findAllUsers();

	User deleteUser(String userId);

	User updateUser( String userId, User user);

}
