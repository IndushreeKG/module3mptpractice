package com.cg.PracticeBirju.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.PracticeBirju.bean.User;
import com.cg.PracticeBirju.service.IUserService;

@RestController
@RequestMapping(value = "/user")
public class Controller {
	
	@Autowired
	private  IUserService userService;
	
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public User addNewUsers( @RequestBody User user) {
		return userService.addNewUser(user);
	}
	
	@RequestMapping(value="/view",method=RequestMethod.GET)
	public List<User> findAllUsers()
	{
		return userService.findAllUsers();
	}
	
	@RequestMapping(value = "/delete/{userId}", method = RequestMethod.DELETE)
	public User deleteUser(@PathVariable String userId)
	{
		return userService.deleteUser(userId);
	}
	
	@RequestMapping(value="/update/{userId}",method=RequestMethod.PUT)
	public User updateUser(@PathVariable String userId, @RequestBody User user)
	{
		System.out.println(userId);
		return userService.updateUser(userId,user);
	}

}
