package com.cg.PracticeBirju.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.PracticeBirju.bean.User;
import com.cg.PracticeBirju.dao.IDao;

@Service
public class UserService implements IUserService
{
	@Autowired
	IDao dao;

	@Override
	public User addNewUser(User user) 
	{
		
		return  dao.addNewUser(user);
	}

	@Override
	public List<User> findAllUsers() 
	{
		return dao.findAllUsers();
	}

	@Override
	public User deleteUser(String userId) 
	{
		return dao.deleteUser(userId);
	}

	@Override
	public User updateUser(String userId,User user) 
	{
		return dao.updateUser(userId,user);
	}
}


