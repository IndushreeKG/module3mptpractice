package com.cg.PracticeBirju.bean;

import java.util.Date;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

public class User {
	
	@Id
	private String userId;
	private String name;
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date dob;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String userId, String name, Date dob) {
		super();
		this.userId = userId;
		this.name = name;
		this.dob = dob;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	
	

}
