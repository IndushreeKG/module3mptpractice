package com.cg.PracticeBirju.service;

import java.util.List;

import com.cg.PracticeBirju.bean.User;

public interface IUserService {

	User addNewUser(User user);

	List<User> findAllUsers();

	User deleteUser(String userId);

	User updateUser(String userId, User user);

	
}
