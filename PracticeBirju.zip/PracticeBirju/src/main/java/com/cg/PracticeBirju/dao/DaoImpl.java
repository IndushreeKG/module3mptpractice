package com.cg.PracticeBirju.dao;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.PracticeBirju.bean.User;
@Repository
public class DaoImpl implements IDao{

	@Autowired
	MongoTemplate mongo;

	@Override
	public User addNewUser(User user) {



		if(user.getDob()==null) 
		{
			Date dob = new Date();
			user.setDob(dob);
			System.out.println(dob);
		}else{
			System.out.println("Date Illa");
		}

		mongo.insert(user);
		return user;
	}



	@Override
	public List<User> findAllUsers() 
	{
		return mongo.findAll(User.class);

	}
	
	
	public User getUserById(String userId) {

		Query query=new Query();
		query.addCriteria(Criteria.where("userId").is(userId));
		return mongo.findOne(query, User.class);
	}

	@Override
	public User deleteUser(String userId) {

		User user=getUserById(userId);
		if(user!=null)
		{
			mongo.remove(user);
		}
		return user;
	}


	@Override
	public User updateUser(String userId,User user) {
		Query query=new Query();
		query.addCriteria(Criteria.where("userId").is(userId));
		user.setUserId(userId);
		mongo.findOne(query, User.class);
		mongo.save(user);
		return user;
	}

}
